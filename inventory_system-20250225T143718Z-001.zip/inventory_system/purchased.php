<?php
    session_start();
    $conn = new mysqli('localhost', 'root', '', 'inventory_system');

    $fetchProducts = "SELECT products.id, products.product_name, products.unit_price, products.product_code FROM products";

    $products = $conn->query($fetchProducts);

    $query = "SELECT id, supplier_name FROM suppliers";
    $result = $conn->query($query);
    $suppliers = $result->fetch_all(MYSQLI_ASSOC);
    
    $conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M Martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Inventory Management</title>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <main class="container px-5 py-3">
        <h1 class="text-center mb-4 fw-semibold">Purchased Data Entry Form</h1>
        <?php
            if (isset($_SESSION['success_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: '" . $_SESSION['success_message'] . "',
                        confirmButtonColor: '#3085d6',
                    });
                </script>";
                unset($_SESSION['success_message']);
            }
            
            // Show error alert
            if (isset($_SESSION['error_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: '" . $_SESSION['error_message'] . "',
                        confirmButtonColor: '#d33',
                    });
                </script>";
                unset($_SESSION['error_message']);
            }
        ?>
        <section class="card p-5 shadow">
            <form action="purchase/process_purchase.php" method="POST">
                <div class="row">
                    <!-- Purchase Date -->
                    <div class="col-md-6 mb-3">
                        <label for="purchase_date" class="form-label">Purchase Date</label>
                        <input type="date" class="form-control" id="purchase_date" name="purchase_date" required value="<?php echo date('Y-m-d'); ?>">
                    </div>

                    <!-- Supplier Name -->
                    <div class="col-md-6 mb-3">
                        <label for="supplier_id" class="form-label">Supplier Name</label>
                        <select class="form-control" id="supplier_id" name="supplier_id" required>
                            <option value="" disabled selected>Select a Supplier</option>
                            <?php foreach ($suppliers as $supplier): ?>
                                <option value="<?= $supplier['id'] ?>"><?= $supplier['supplier_name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <!-- Product/Item Name -->
                    <div class="col-md-6 mb-3">
                        <label for="product_name" class="form-label">Product/Item Name</label>
                        <select class="form-select" id="product_name" name="product_name" required onchange="updateUnitPrice()">
                            <option value="">Select an item</option>
                            <?php
                                if ($products->num_rows > 0) {
                                    while ($row = $products->fetch_assoc()) {
                                        echo "<option value='" . $row['id'] . "' data-unit_price='" . $row['unit_price'] . "' data-product_code='" . $row['product_code'] . "'>" 
                                            . htmlspecialchars($row['product_name']) . 
                                            "</option>";
                                    }
                                } else {
                                    echo "<option value=''>No products available</option>";
                                }
                            ?>
                        </select>
                        <!-- Invoice Number -->
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="invoice_number" class="form-label">Invoice Number</label>
                        <input type="text" class="form-control" id="invoice_number" name="invoice_number" required readonly>
                    </div>
                </div>

                <div class="row">
                    <!-- Quantity -->
                    <div class="col-md-4 mb-3">
                        <label for="quantity" class="form-label">Quantity</label>
                        <input type="number" class="form-control" id="quantity" name="quantity" required min="1" oninput="calculateTotal()">
                    </div>

                    <!-- Unit Price -->
                    <div class="col-md-4 mb-3">
                        <label for="unit_price" class="form-label">Unit Price</label>
                        <input type="number" class="form-control" id="unit_price" name="unit_price" required step="0.01" readonly>
                    </div>

                    <!-- Total Amount -->
                    <div class="col-md-4 mb-3">
                        <label for="total_amount" class="form-label">Total Amount</label>
                        <input type="text" class="form-control" id="total_amount" name="total_amount" readonly>
                    </div>
                </div>

                <div class="row">
                    <!-- Discount -->
                    <div class="col-md-4 mb-3">
                        <label for="discount" class="form-label">Discount (Optional)</label>
                        <input type="number" class="form-control" id="discount" name="discount" min="0" step="0.01" oninput="calculateGrandTotal()">
                    </div>

                    <!-- Tax Amount -->
                    <div class="col-md-4 mb-3">
                        <label for="tax_amount" class="form-label">Tax Amount (Optional)</label>
                        <input type="number" class="form-control" id="tax_amount" name="tax_amount" min="0" step="0.01" oninput="calculateGrandTotal()">
                    </div>

                    <!-- Grand Total -->
                    <div class="col-md-4 mb-3">
                        <label for="grand_total" class="form-label">Grand Total</label>
                        <input type="text" class="form-control" id="grand_total" name="grand_total" readonly>
                    </div>
                </div>

                <div class="row">
                    <!-- Payment Method -->
                    <div class="col-md-6 mb-3">
                        <label for="payment_method" class="form-label">Payment Method</label>
                        <select class="form-select" id="payment_method" name="payment_method" required>
                            <option value="Cash">Cash</option>
                            <option value="Credit">Credit</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                        </select>
                    </div>

                    <!-- Payment Status -->
                    <div class="col-md-6 mb-3">
                        <label for="payment_status" class="form-label">Payment Status</label>
                        <select class="form-select" id="payment_status" name="payment_status" required>
                            <option value="Paid">Paid</option>
                            <option value="Unpaid">Unpaid</option>
                            <option value="Partially Paid">Partially Paid</option>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <!-- Purchase Status -->
                    <div class="col-md-6 mb-3">
                        <label for="purchase_status" class="form-label">Purchase Status</label>
                        <select class="form-select" id="purchase_status" name="purchase_status" required>
                            <option value="Pending">Pending</option>
                            <option value="Received">Received</option>
                            <option value="Canceled">Canceled</option>
                        </select>
                    </div>

                    <!-- Notes -->
                    <div class="col-md-6 mb-3">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary w-100">Submit Purchase</button>
                    </div>
                </div>
            </form>


        </section>
    </main>

    <script>
        function updateUnitPrice() {
            const productSelect = document.getElementById('product_name');
            const unitPriceInput = document.getElementById('unit_price');
            const totalAmountInput = document.getElementById('total_amount');
            const quantityInput = document.getElementById('quantity');
            const invoiceNumberInput = document.getElementById('invoice_number');
            
            quantityInput.value = 1;

            const selectedOption = productSelect.options[productSelect.selectedIndex];
            
            const unitPrice = parseFloat(selectedOption.getAttribute('data-unit_price')) || 0;
            unitPriceInput.value = unitPrice.toFixed(2);
            const productCode = selectedOption.getAttribute('data-product_code');

            if (productCode) {
                invoiceNumberInput.value = productCode;
            } else {
                invoiceNumberInput.value = "";
            }
            
            calculateTotal();
        }

        function calculateTotal() {
            const quantity = parseFloat(document.getElementById('quantity').value) || 0;
            const unitPrice = parseFloat(document.getElementById('unit_price').value) || 0;
            const totalAmountInput = document.getElementById('total_amount');
            
            const totalAmount = quantity * unitPrice;
            totalAmountInput.value = totalAmount.toFixed(2);
            
            calculateGrandTotal();
        }

        function calculateGrandTotal() {
            const totalAmount = parseFloat(document.getElementById('total_amount').value) || 0;
            const discount = parseFloat(document.getElementById('discount').value) || 0;
            const taxAmount = parseFloat(document.getElementById('tax_amount').value) || 0;
            const grandTotalInput = document.getElementById('grand_total');
            
            const grandTotal = totalAmount + taxAmount - discount;
            grandTotalInput.value = grandTotal.toFixed(2);
        }

        document.getElementById('quantity').addEventListener('input', calculateTotal);
        document.getElementById('discount').addEventListener('input', calculateGrandTotal);
        document.getElementById('tax_amount').addEventListener('input', calculateGrandTotal);
        document.getElementById('product_name').addEventListener('change', updateUnitPrice);

        document.addEventListener('DOMContentLoaded', function() {
            updateUnitPrice();
        });
    </script>

</body>
</html>