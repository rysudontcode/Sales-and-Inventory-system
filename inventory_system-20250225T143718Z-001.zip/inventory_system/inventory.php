<?php
    session_start();
    $conn = new mysqli('localhost', 'root', '', 'inventory_system');

    $fetchProducts = "SELECT 
                        products.id, 
                        products.uuid, 
                        products.product_code, 
                        products.product_name, 
                        categories.category_name, 
                        products.stock_quantity, 
                        products.unit_price, 
                        products.created_at, 
                        suppliers.supplier_name
                    FROM products
                    JOIN categories ON products.category_id = categories.id
                    JOIN suppliers ON products.supplier_id = suppliers.id
                    ORDER BY products.created_at DESC";

    $products = $conn->query($fetchProducts);

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        
        $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
        $product_code = mysqli_real_escape_string($conn, $_POST['product_code']);
        $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
        $stock_quantity = mysqli_real_escape_string($conn, $_POST['stock_quantity']);
        $unit_price = mysqli_real_escape_string($conn, $_POST['unit_price']);
        $supplier_id = mysqli_real_escape_string($conn, $_POST['supplier_id']);
    
        $uuid = uniqid('', true);
        
        $query = "INSERT INTO products (uuid, product_name, product_code, category_id, stock_quantity, unit_price, supplier_id, created_at, updated_at)
                  VALUES ('$uuid', '$product_name', '$product_code', '$category_id', '$stock_quantity', '$unit_price', '$supplier_id', NOW(), NOW())";
    
        if (mysqli_query($conn, $query)) {
            $product_id = mysqli_insert_id($conn);

            $category_query = "INSERT INTO product_categories (product_id, category_id, created_at, updated_at) VALUES ('$product_id', '$category_id', NOW(), NOW())";
            
            if (mysqli_query($conn, $category_query)) {
                $_SESSION['success_message'] = "Record added successfully!";
            } else {
                $_SESSION['error_message'] = "Error adding category data: " . mysqli_error($conn);
            }
    
            header("Location: " . $_SERVER['PHP_SELF']);
            exit(); 
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M. Martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Inventory Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
        }

        .eye-icon-link-view {
            display: inline-block; 
            background-color: #3b82f6; 
            padding: .3rem .7rem .3rem .7rem;
            border-radius: .4rem; 
            text-decoration: none;
        }

        .eye-icon-link-view i {
            color: white;  
            font-size: 1rem;
        }

        .eye-icon-link-view:hover {
            background-color: #2563eb; 
        }

        .eye-icon-link-edit {
            display: inline-block; 
            background-color: #34d399;
            padding: .3rem .7rem .3rem .7rem;
            border-radius: .4rem; 
            text-decoration: none;
            cursor: pointer;
        }

        .eye-icon-link-edit i {
            color: white;  
            font-size: 1rem;
        }

        .eye-icon-link-edit:hover {
            background-color: #10b981;
        }

        .eye-icon-link-delete {
            display: inline-block; 
            background-color: #f87171;
            padding: .3rem .7rem .3rem .7rem;
            border-radius: .4rem; 
            text-decoration: none;
            cursor: pointer;
        }

        .eye-icon-link-delete i {
            color: white;  
            font-size: 1rem;
        }

        .eye-icon-link-delete:hover {
            background-color: #ef4444;
        }

        label {
            margin-bottom: 20px;
        }
    </style>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <main class="container px-5 py-3">
        <h1 class="text-center mb-4 fw-semibold">Sales and Inventory system </h1>

        <?php
            if (isset($_SESSION['success_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: '" . $_SESSION['success_message'] . "',
                        confirmButtonColor: '#3085d6',
                    });
                </script>";
                unset($_SESSION['success_message']);
            }
            
            // Show error alert
            if (isset($_SESSION['error_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: '" . $_SESSION['error_message'] . "',
                        confirmButtonColor: '#d33',
                    });
                </script>";
                unset($_SESSION['error_message']);
            }
        ?>
        <!-- Product List Section -->
        <section class="mb-5 bg-white shadow px-4 py-5 rounded">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h2 class="fw-semibold fs-3 mb-3">Product List</h2>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    Add New Product
                </button>
            </div>
            <div class="mb-3 w-25">
                <label for="categoryFilter">Filter by Category:</label>
                <select id="categoryFilter" class="form-control">
                    <option value="">All Categories</option>
                    <?php
                    $categoryQuery = "SELECT DISTINCT category_name FROM categories";
                    $categoryResult = $conn->query($categoryQuery);
                    
                    while ($categoryRow = $categoryResult->fetch_assoc()) {
                        echo "<option value='" . $categoryRow['category_name'] . "'>" . $categoryRow['category_name'] . "</option>";
                    }
                    ?>
                </select>
            </div>

            <table id="productTable" class="table table-hover">
                <thead class="text-white" style="background-color:rgb(114, 179, 232)">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Code</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Category</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Price</th>
                        <th scope="col">Date of Entry</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($products->num_rows > 0) {
                        $i = 1;
                        while ($row = $products->fetch_assoc()) {
                            $stockClass = "";
                            $stockMessage = "";
                            
                            if ($row['stock_quantity'] == 0) {
                                $stockClass = "badge w-50 bg-danger";
                                $stockMessage = "Out of Stock";
                            } elseif ($row['stock_quantity'] < 20) {
                                $stockClass = "badge w-50 bg-warning text-dark";
                                $stockMessage = "Low Stock";
                            } else {
                                $stockClass = "badge w-50 bg-success";
                                $stockMessage = "In Stock";
                            }
                            
                            echo "<tr>";
                                echo "<td>" . $i++ . "</td>";
                                echo "<td>" . $row['product_code'] . "</td>";
                                echo "<td>" . $row['product_name'] . "</td>";
                                echo "<td class='category-column'>" . $row['category_name'] . "</td>"; // Display Category Name
                                echo "<td>
                                        <span class='$stockClass' data-bs-toggle='tooltip' title='$stockMessage'>
                                            " . $row['stock_quantity'] . "
                                        </span>
                                    </td>";
                                echo "<td>₱ " . number_format($row['unit_price'], 2) . "</td>";
                                echo "<td>" . date('F j, Y', strtotime($row['created_at'])) . "</td>";
                                echo "<td>
                                    <div class='eye-icon-link-edit' data-bs-toggle='modal' data-bs-target='#editModal' onclick=\"setEditUuid('" . $row['id'] . "')\">
                                        <i class='fas fa-edit'></i>
                                    </div>
                                    <div class='eye-icon-link-delete' data-bs-toggle='modal' data-bs-target='#deleteModal' onclick=\"setDeleteUuid('" . $row['id'] . "')\">
                                        <i class='fas fa-trash'></i>
                                    </div>
                                </td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No products found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>


        </section>
    </main>

    <!-- Modal for additional -->
    <div class="modal fade" id="addProductModal" tabindex="-1" aria-labelledby="addProductModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addProductModalLabel">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row" action="inventory.php" method="post">
                        <div class="col-12">
                            <label class="form-label" for="product">Product Name</label>
                            <input type="text" name="product_name" class="form-control" id="product" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="code">Product Code</label>
                            <input type="text" name="product_code" class="form-control" id="code" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="category">Category</label>
                            <select name="category_id" class="form-control" id="category" required>
                                <option value="">Select Category</option>
                                <?php
                                $fetchCategories = "SELECT id, category_name FROM categories";
                                $categories = $conn->query($fetchCategories);
                                if ($categories->num_rows > 0) {
                                    while ($row = $categories->fetch_assoc()) {
                                        echo "<option value='" .$row['id'] . "'>" . $row['category_name'] . "</option>";
                                    }
                                } else {
                                    echo "No categories found.";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="quantity">Stock Quantity</label>
                            <input type="number" name="stock_quantity" class="form-control" id="quantity" min="0" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="price">Unit Price</label>
                            <input type="text" name="unit_price" class="form-control" id="price" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="suppliers">Suppliers</label>
                            <select name="supplier_id" class="form-control" id="suppliers" required>
                                <option value="">Select Supplier</option>
                                <?php
                                $fetchSupplier = "SELECT id, supplier_name FROM suppliers";
                                $suppliers = $conn->query($fetchSupplier);
                                if ($suppliers->num_rows > 0) {
                                    while ($row = $suppliers->fetch_assoc()) {
                                        echo "<option value='" .$row['id'] . "'>" . $row['supplier_name'] . "</option>";
                                    }
                                } else {
                                    echo "No suppliers found.";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-primary w-100">Add Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for update -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addProductModalLabel">Update Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form class="row" action="inventory/update.php" method="post">
                        <input type="hidden" name="product_uuid" id="product_uuid">
                        <div class="col-12">
                            <label class="form-label" for="edit_product">Product Name</label>
                            <input type="text" name="product_name" class="form-control" id="edit_product" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="edit_code">Product Code</label>
                            <input type="text" name="product_code" class="form-control" id="edit_code" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="edit_category">Category</label>
                            <select name="category_id" class="form-control" id="edit_category" required>
                                <option value="">Select Category</option>
                                <?php
                                $fetchCategories = "SELECT id, category_name FROM categories";
                                $categories = $conn->query($fetchCategories);
                                if ($categories->num_rows > 0) {
                                    while ($row = $categories->fetch_assoc()) {
                                        echo "<option value='" .$row['id'] . "'>" . $row['category_name'] . "</option>";
                                    }
                                } else {
                                    echo "No categories found.";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="edit_quantity">Stock Quantity</label>
                            <input type="number" name="stock_quantity" class="form-control" id="edit_quantity" min="0" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="edit_price">Unit Price</label>
                            <input type="text" name="unit_price" class="form-control" id="edit_price" required>
                        </div>
                        <div class="col-12 mt-2">
                            <label class="form-label" for="edit_suppliers">Suppliers</label>
                            <select name="supplier_id" class="form-control" id="edit_suppliers" required>
                                <option value="">Select Supplier</option>
                                <?php
                                $fetchSupplier = "SELECT id, supplier_name FROM suppliers";
                                $suppliers = $conn->query($fetchSupplier);
                                if ($suppliers->num_rows > 0) {
                                    while ($row = $suppliers->fetch_assoc()) {
                                        echo "<option value='" .$row['id'] . "'>" . $row['supplier_name'] . "</option>";
                                    }
                                } else {
                                    echo "No suppliers found.";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-12 mt-4">
                            <button type="submit" class="btn btn-primary w-100">Update Product</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for delete -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Confirm Deletion</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure you want to delete this item?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <a href="#" id="confirmDeleteBtn" class="btn btn-danger">Delete</a>
                </div>
            </div>
        </div>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/js/bootstrap.min.js"></script>

    <script>
        $(document).ready(function () {
            var table = $('#productTable').DataTable();

            $('#categoryFilter').on('change', function () {
                var selectedCategory = $(this).val();
                table.column(3).search(selectedCategory).draw();
            });
        });

        function setDeleteUuid(id) {
            document.getElementById("confirmDeleteBtn").href = "inventory/delete.php?id=" + id;
        }

        function setEditUuid(id) {
            fetch('inventory/get_record.php?id=' + id)
            .then(response => response.json())
            .then(data => {
                console.log(data);
                document.getElementById('product_uuid').value = id;
                document.getElementById('edit_product').value = data.product_name;
                document.getElementById('edit_code').value = data.product_code;
                document.getElementById('edit_category').value = data.category_id;
                document.getElementById('edit_quantity').value = data.stock_quantity;
                document.getElementById('edit_suppliers').value = data.supplier_id;
                document.getElementById('edit_price').value = data.unit_price;
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
        }

        function getRecords(id) {
            // todo: getrecords
        }

    </script>
</body>
</html>