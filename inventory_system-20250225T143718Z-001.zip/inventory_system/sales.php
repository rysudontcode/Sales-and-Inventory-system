<?php
    session_start();
    $conn = new mysqli('localhost', 'root', '', 'inventory_system');

    $fetchProducts = "SELECT products.id, products.product_name, products.unit_price FROM products";

    $products = $conn->query($fetchProducts);

    $conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M Martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Inventory Management</title>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <main class="container px-5 py-3">
        <h1 class="text-center mb-4 fw-semibold">Sales Data Entry Form</h1>
        <?php
            if (isset($_SESSION['success_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Success!',
                        text: '" . $_SESSION['success_message'] . "',
                        confirmButtonColor: '#3085d6',
                    });
                </script>";
                unset($_SESSION['success_message']);
            }
            
            // Show error alert
            if (isset($_SESSION['error_message'])) {
                echo "<script>
                    Swal.fire({
                        icon: 'error',
                        title: 'Error!',
                        text: '" . $_SESSION['error_message'] . "',
                        confirmButtonColor: '#d33',
                    });
                </script>";
                unset($_SESSION['error_message']);
            }
        ?>
        <section class="card p-5 shadow">
        <form action="sales/process_sales.php" method="POST">
            <div class="row">
                <!-- Sale Date -->
                <div class="col-md-6 mb-3">
                    <label for="sale_date" class="form-label">Sale Date</label>
                    <input type="date" class="form-control" id="sale_date" name="sale_date" required value="<?php echo date('Y-m-d'); ?>">
                </div>

                <!-- Sales Representative -->
                <div class="col-md-6 mb-3">
                    <label for="sales_rep" class="form-label">Sales Representative</label>
                    <input type="text" class="form-control" id="sales_rep" name="sales_rep" required>
                </div>
            </div>

            <div class="row">
                <!-- Customer Name -->
                <div class="col-md-6 mb-3">
                    <label for="customer_name" class="form-label">Customer Name</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name" required>
                </div>

                <!-- Customer ID -->
                <div class="col-md-6 mb-3">
                    <label for="customer_id" class="form-label">Customer ID</label>
                    <input type="text" class="form-control" id="customer_id" name="customer_id" required>
                </div>
            </div>

            <div class="row">
                <!-- Product -->
                <div class="col-md-6 mb-3">
                    <label for="product" class="form-label">Product/Service</label>
                    <select class="form-select" id="product" name="product" required onchange="updateUnitPrice()">
                        <option value="">Select a product</option>
                        <?php
                            if ($products->num_rows > 0) {
                                while ($row = $products->fetch_assoc()) {
                                    echo "<option value='" . $row['id'] . "' data-unit_price='" . $row['unit_price'] . "'>" 
                                        . htmlspecialchars($row['product_name']) . 
                                        "</option>";
                                }
                            } else {
                                echo "<option value=''>No products available</option>";
                            }
                        ?>
                    </select>
                </div>

                <!-- Quantity -->
                <div class="col-md-6 mb-3">
                    <label for="quantity" class="form-label">Quantity</label>
                    <input type="number" class="form-control" id="quantity" name="quantity" required min="1" oninput="calculateTotal()">
                </div>
            </div>

            <div class="row">
                <!-- Unit Price -->
                <div class="col-md-6 mb-3">
                    <label for="unit_price" class="form-label">Unit Price</label>
                    <input type="number" class="form-control" id="unit_price" name="unit_price" required step="0.01" readonly>
                </div>

                <!-- Total Amount -->
                <div class="col-md-6 mb-3">
                    <label for="total_amount" class="form-label">Total Amount</label>
                    <input type="text" class="form-control" id="total_amount" name="total_amount" readonly>
                </div>
            </div>

            <div class="row">
                <!-- Payment Status -->
                <div class="col-md-6 mb-3">
                    <label for="payment_status" class="form-label">Payment Status</label>
                    <select class="form-select" id="payment_status" name="payment_status" required>
                        <option value="Paid">Paid</option>
                        <option value="Pending">Pending</option>
                        <option value="Partially Paid">Partially Paid</option>
                    </select>
                </div>

                <!-- Notes -->
                <div class="col-md-6 mb-3">
                    <label for="notes" class="form-label">Notes</label>
                    <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                </div>
            </div>

            <!-- Submit Button -->
            <div class="row">
                <div class="col-12">
                    <button type="submit" class="btn btn-primary w-100">Submit Sale</button>
                </div>
            </div>
        </form>

        </section>
    </main>
    <script>
        function updateUnitPrice() {
            var productSelect = document.getElementById("product");
            var unitPriceInput = document.getElementById("unit_price");
            var productQuantityInput = document.getElementById("quantity");

            var selectedOption = productSelect.options[productSelect.selectedIndex];
            var unitPrice = selectedOption.getAttribute("data-unit_price");
            
            unitPriceInput.value = unitPrice ? unitPrice : "";
            productQuantityInput.value = 1;

            calculateTotal();
        }

        function calculateTotal() {
            let quantity = document.getElementById('quantity').value;
            let unitPrice = document.getElementById('unit_price').value;
            let total = quantity * unitPrice;
            document.getElementById('total_amount').value = total ? total.toFixed(2) : '';
        }
    </script>

</body>
</html>