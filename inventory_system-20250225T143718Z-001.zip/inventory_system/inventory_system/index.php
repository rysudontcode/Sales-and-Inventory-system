<?php
    $conn = new mysqli('localhost', 'root', '', 'inventory_system');

    $sql = "SELECT COUNT(*) as total_products 
        FROM products 
        JOIN categories ON products.category_id = categories.id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // echo "Total Products: " . $row['total_products'] . "<br>";
    } else {
        // echo "No products found.";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Inventory Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
        }
    </style>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <main class="w-100 p-4">
        <!-- Informational Cards -->
        <section class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-3 mb-6">
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Total Products</p>
                                <h5 class="mb-0 fw-bold"><?= $row['total_products']; ?></h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-regular fa-file text-white fs-4"></i> -->
                                    <i class="fas fa-box-open text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Low Stock Items</p>
                                <h5 class="mb-0 fw-bold">31</h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <i class="fas fa-exclamation-circle text-4xl text-white"></i>
                                    <!-- <span class="text-white fs-4">✔</span> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Out of Stock</p>
                                <h5 class="mb-0 fw-bold">41</h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-solid fa-xmark text-white fs-4"></i> -->
                                    <i class="fas fa-times-circle text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Recent Transactions</p>
                                <h5 class="mb-0 fw-bold">41</h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-solid fa-business-time text-white fs-4"></i> -->
                                    <i class="fas fa-cash-register text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</body>

</html>