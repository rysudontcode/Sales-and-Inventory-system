<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Inventory Management</title>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <h1>Hello World sa sales</h1>
</body>
</html>