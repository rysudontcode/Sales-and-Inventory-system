<?php
session_start();
require 'db_connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "SELECT * FROM products WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {
            echo json_encode([
                // 'id' => $row['id'],
                'product_name' => $row['product_name'],
                'product_code' => $row['product_code'],
                'category_id' => $row['category_id'],
                'stock_quantity' => $row['stock_quantity'],
                'unit_price' => $row['unit_price'],
                'supplier_id' => $row['supplier_id'],
            ]);
        } else {
            echo json_encode(['error' => 'No record found']);
        }

        $stmt->close();
    } else {
        echo json_encode(['error' => 'Error preparing statement']);
    }

    $conn->close();
} else {
    echo json_encode(['error' => 'UUID is missing']);
}