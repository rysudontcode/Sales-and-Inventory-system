<?php
session_start();
require 'db_connection.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $sql = "DELETE FROM products WHERE id = ?";

    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $id);

        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Record deleted successfully!";
        } else {
            $_SESSION['error_message'] = "Error deleting record: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Error preparing statement: " . $conn->error;
    }

    $conn->close();
} else {
    $_SESSION['error_message'] = "Invalid request: UUID is missing.";
}

header("Location: /inventory_system/inventory.php");
exit();

