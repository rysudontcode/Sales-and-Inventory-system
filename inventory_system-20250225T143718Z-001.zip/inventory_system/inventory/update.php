<?php

session_start();
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_uuid'];
    $product_name = $_POST['product_name'];
    $product_code = $_POST['product_code'];
    $category_id = $_POST['category_id'];
    $stock_quantity = $_POST['stock_quantity'];
    $unit_price = $_POST['unit_price'];
    $supplier_id = $_POST['supplier_id'];

    if (empty($product_name) || empty($product_code) || empty($category_id) || empty($stock_quantity) || empty($unit_price) || empty($supplier_id)) {
        echo "All fields are required.";
        exit;
    }

    $query = "UPDATE products SET product_name = ?, product_code = ?, category_id = ?, stock_quantity = ?, unit_price = ?, supplier_id = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssiidsi", $product_name, $product_code, $category_id, $stock_quantity, $unit_price, $supplier_id, $product_id);

    if ($stmt->execute()) {
        // echo "Product updated successfully.";
        $_SESSION['success_message'] = "Record updated successfully!";
    } else {
        // echo "Error updating product: " . $conn->error;
        $_SESSION['error_message'] = "Error updating record: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
    
    header("Location: /inventory_system/inventory.php");
    exit();
} else {
    echo "Invalid request.";
}