<?php
    $conn = new mysqli('localhost', 'root', '', 'inventory_system');

    // Total Products
    $total_products = "SELECT COUNT(*) as total_products 
        FROM products 
        JOIN categories ON products.category_id = categories.id";
    $result_total = $conn->query($total_products);

    if ($result_total->num_rows > 0) {
        $row1 = $result_total->fetch_assoc();
        // echo "Total Products: " . $row1['total_products'] . "<br>";
    } else {
        // echo "No products found.";
    }

    // How Many Stocks
    $stocks = "SELECT 
        COUNT(CASE WHEN stock_quantity < 10 THEN 1 END) as low_stock_count,
        COUNT(CASE WHEN stock_quantity = 0 THEN 1 END) as out_of_stock_count,
        COUNT(CASE WHEN stock_quantity > 0 THEN 1 END) as in_stock_count
    FROM products"; 
    $result_low_stock = $conn->query($stocks);

    $lowStockCount = 0;
    $outOfStockCount = 0;
    $inStockCount = 0;

    if ($result_low_stock->num_rows > 0) {
        $row2 = $result_low_stock->fetch_assoc();
        $lowStockCount = $row2['low_stock_count'];
        $outOfStockCount = $row2['out_of_stock_count'];
        $inStockCount = $row2['in_stock_count'];
    }

    // 12 months
    $stocksQuery = "SELECT 
                    DATE_FORMAT(created_at, '%Y-%m') AS month, 
                    product_name, 
                    SUM(stock_quantity) AS total_stock
                FROM products
                WHERE created_at >= CURDATE() - INTERVAL 12 MONTH
                GROUP BY month, product_name
                ORDER BY month ASC";

    $result = $conn->query($stocksQuery);

    // Prepare data arrays
    $stockData = [];
    $products = [];

    while ($row = $result->fetch_assoc()) {
        $month = date('M', strtotime($row['month'])); // Convert to 'Jan', 'Feb', etc.
        $productName = $row['product_name'];
        $stockQuantity = (int)$row['total_stock'];

        // Store product names
        if (!in_array($productName, $products)) {
            $products[] = $productName;
        }

        // Store stock data
        $stockData[$productName][$month] = $stockQuantity;
    }

    // Ensure all months are present in case some are missing
    $allMonths = [];
    $currentMonth = date('n'); // Get current month number (1-12)
    for ($i = 11; $i >= 0; $i--) {
        $allMonths[] = date('M', strtotime("-$i months"));
    }

    // Prepare final dataset ensuring every product has data for each month
    $finalStockData = [];
    foreach ($products as $product) {
        $productStock = [];
        foreach ($allMonths as $month) {
            $productStock[] = $stockData[$product][$month] ?? 0;
        }
        $finalStockData[] = [
            "label" => $product,
            "data" => $productStock,
            "fill" => true,
            "borderColor" => "rgba(" . rand(0, 255) . "," . rand(0, 255) . "," . rand(0, 255) . ",1)",
            "backgroundColor" => "rgba(0, 0, 0, 0)",
            "borderWidth" => 2,
            "tension" => 0.4
        ];
    }

    $conn->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Kent Adrian M. Martinez">
    <meta name="description" content="An inventory system">
    <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-5.0.2-dist/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Inventory Management</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            user-select: none;
        }
    </style>
</head>
<body class="d-flex bg-light">
    <aside>
        <?php include 'components/sidebar.html'; ?>
    </aside>
    <main class="w-100 p-4">
        <!-- Informational Cards -->
        <section class="row row-cols-1 row-cols-md-2 row-cols-lg-4 mb-6">
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Total Products</p>
                                <h5 class="mb-0 fw-bold"><?= $row1['total_products']; ?></h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-regular fa-file text-white fs-4"></i> -->
                                    <i class="fas fa-box-open text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Low Stock Items</p>
                                <h5 class="mb-0 fw-bold"><?= $lowStockCount; ?></h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <i class="fas fa-exclamation-circle text-4xl text-white"></i>
                                    <!-- <span class="text-white fs-4">✔</span> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Out of Stock</p>
                                <h5 class="mb-0 fw-bold"><?= $outOfStockCount;?></h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-solid fa-xmark text-white fs-4"></i> -->
                                    <i class="fas fa-times-circle text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-2">
                <div class="card shadow-sm rounded-3" style="height: 6rem;">
                    <div class="card-body">
                        <div class="d-flex flex-wrap">
                            <div class="col-8">
                                <p class="mb-0 fs-6 fw-semibold">Recent Transactions</p>
                                <h5 class="mb-0 fw-bold">41</h5>
                            </div>
                            <div class="col-4 text-end">
                                <div class="d-inline-block p-3 bg-secondary rounded shadow">
                                    <!-- <i class="fa-solid fa-business-time text-white fs-4"></i> -->
                                    <i class="fas fa-cash-register text-4xl text-white"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Charts -->
        <section class="row d-flex align-items-stretch mt-4">
            <!-- Line Chart Section (60%) -->
            <div class="px-2 col-7">
                <div class="card shadow p-5 h-100">
                    <h3>Product Count Comparison (Last 12 Months)</h3>
                    <canvas id="stockLineChart" height="500"></canvas>
                </div>
            </div>


            <!-- Pie Chart Section (40%) -->
            <div class="px-2 col-5">
                <div class="card shadow p-5 h-100">
                    <h3>Stock Overview</h3>
                    <canvas id="stockPieChart"></canvas>
                </div>
            </div>
        </section>

    </main>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('stockLineChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: <?= json_encode($allMonths); ?>,
                datasets: <?= json_encode($finalStockData); ?>
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    },
                    x: {
                        display: false
                    }
                },
                plugins: {
                    legend: { position: 'top' }
                },
                elements: {
                    line: {
                        fill: true
                    }
                }
            }
        });

        const pieChartCtx = document.getElementById('stockPieChart').getContext('2d');
        const stockPieChart = new Chart(pieChartCtx, {
            type: 'doughnut',
            data: {
                labels: ['Low Stock', 'Out of Stock', 'In Stock'],
                datasets: [{
                    label: 'Stock Overview',
                    data: [<?php echo $lowStockCount; ?>, <?php echo $outOfStockCount; ?>, <?php echo $inStockCount; ?>],
                    backgroundColor: [
                        'rgba(255, 206, 86, 0.6)',
                        'rgba(255, 99, 132, 0.6)',
                        'rgba(75, 192, 192, 0.6)'
                    ],
                    borderColor: [
                        'rgba(255, 206, 86, 1)',
                        'rgba(255, 99, 132, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 1
                }]
            }
        });
    </script>
</body>

</html>