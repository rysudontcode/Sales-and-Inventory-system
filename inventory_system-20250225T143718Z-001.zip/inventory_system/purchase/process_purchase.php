<?php
session_start();

require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $purchase_date = $_POST['purchase_date'];
    $supplier_id = $_POST['supplier_id'];
    $invoice_number = $_POST['invoice_number'];
    $product_name = $_POST['product_name'];
    $quantity = $_POST['quantity'];
    $unit_price = $_POST['unit_price'];
    $total_amount = $_POST['total_amount'];
    $discount = $_POST['discount'];
    $tax_amount = $_POST['tax_amount'];
    $grand_total = $_POST['grand_total'];
    $payment_method = $_POST['payment_method'];
    $payment_status = $_POST['payment_status'];
    $purchase_status = $_POST['purchase_status'];
    $notes = $_POST['notes'];

    $query = "INSERT INTO purchases (purchase_date, supplier_id, invoice_number, product_id, quantity, unit_price, total_amount, discount, tax_amount, grand_total, payment_method, payment_status, purchase_status, notes)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("ssssiiddddsdss", $purchase_date, $supplier_id, $invoice_number, $product_name, $quantity, $unit_price, $total_amount, $discount, $tax_amount, $grand_total, $payment_method, $payment_status, $purchase_status, $notes);
        
        if ($stmt->execute()) {
            $update_query = "UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?";
            if ($update_stmt = $conn->prepare($update_query)) {
                $update_stmt->bind_param("is", $quantity, $product_name);
                if ($update_stmt->execute()) {
                    $_SESSION['success_message'] = "Purchase has been successfully processed and stock updated!";
                } else {
                    $_SESSION['error_message'] = "An error occurred while updating the stock.";
                }
                $update_stmt->close();
            } else {
                $_SESSION['error_message'] = "Error: " . $conn->error;
            }
        } else {
            $_SESSION['error_message'] = "An error occurred while processing the purchase.";
        }
        $stmt->close();
    } else {
        $_SESSION['error_message'] = "Error: " . $conn->error;
    }

    header('Location: /inventory_system/purchased.php');
    exit;
}
?>
