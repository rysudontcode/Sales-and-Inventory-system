<?php
session_start();
require 'db_connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $sale_date = $_POST['sale_date'];
    $sales_rep = $_POST['sales_rep'];
    $customer_name = $_POST['customer_name'];
    $customer_id = $_POST['customer_id'];
    $product_id = $_POST['product'];
    $quantity = $_POST['quantity'];
    $unit_price = $_POST['unit_price'];
    $total_amount = $_POST['total_amount'];
    $payment_status = $_POST['payment_status'];
    $notes = $_POST['notes'];
    $current_timestamp = date('Y-m-d H:i:s');

    $_SESSION['form_data'] = $_POST;

    // Check ang stock availability
    $check_stock_query = "SELECT stock_quantity FROM products WHERE id = ?";
    $stmt = $conn->prepare($check_stock_query);
    $stmt->bind_param("s", $product_id);
    $stmt->execute();
    $stmt->bind_result($stock_quantity);
    $stmt->fetch();
    $stmt->close();

    if ($quantity > $stock_quantity) {
        $_SESSION['error_message'] = "Insufficient stock! Only $stock_quantity items available.";
        header("Location: /inventory_system/sales.php");
        exit();
    }

    $stmt = $conn->prepare("INSERT INTO sales (sale_date, sales_rep, customer_name, customer_id, product_id, quantity, unit_price, total_amount, payment_status, notes, created_at, updated_at) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssiidsssss", $sale_date, $sales_rep, $customer_name, $customer_id, $product_id, $quantity, $unit_price, $total_amount, $payment_status, $notes, $current_timestamp, $current_timestamp);

    if ($stmt->execute()) {
        // Update stock quantity
        $update_query = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?";
        if ($update_stmt = $conn->prepare($update_query)) {
            $update_stmt->bind_param("is", $quantity, $product_id);
            if ($update_stmt->execute()) {
                $_SESSION['success_message'] = "Sale recorded successfully! Stock updated.";
                $_SESSION['alert_type'] = "success";
                unset($_SESSION['form_data']);
            } else {
                $_SESSION['error_message'] = "Sale recorded, but stock update failed.";
            }
            $update_stmt->close();
        }
    } else {
        $_SESSION['error_message'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header("Location: /inventory_system/sales.php");
    exit();
} else {
    $_SESSION['error_message'] = "Invalid request!";
    header("Location: sales.php");
    exit();
}
