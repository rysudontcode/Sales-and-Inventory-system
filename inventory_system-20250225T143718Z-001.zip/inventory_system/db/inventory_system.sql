-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 09, 2025 at 07:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`) VALUES
(1, 'Construction Materials'),
(2, 'Tools'),
(3, 'Safety Equipment'),
(4, 'Electrical Supplies'),
(5, 'Plumbing Supplies'),
(6, 'Paint and Finishes'),
(7, 'Lumber and Wood Products'),
(8, 'Hardware'),
(9, 'Pipes and Fittings'),
(10, 'Adhesives and Sealants'),
(11, 'Tiles and Flooring'),
(12, 'Cement and Concrete'),
(13, 'Hand Tools'),
(14, 'Power Tools'),
(15, 'Garden and Landscaping'),
(16, 'Roofing Materials'),
(17, 'Insulation Materials'),
(18, 'Construction Machinery'),
(19, 'Scaffolding'),
(20, 'Heavy Equipment'),
(21, 'Fasteners and Bolts'),
(22, 'Work Apparel');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2025_01_28_185404_create_categories_table', 1),
(2, '2025_01_28_185438_create_suppliers_table', 1),
(3, '2025_01_28_185439_create_products_table', 1),
(4, '2025_02_05_161914_create_purchases_table', 1),
(5, '2025_02_09_180941_create_sales_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_code` varchar(255) NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `unit_price` varchar(255) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `uuid`, `product_name`, `product_code`, `supplier_id`, `category_id`, `unit_price`, `stock_quantity`, `created_at`, `updated_at`) VALUES
(1, 'ff9dd4b9-667f-498d-a686-427b1ab1823f', 'Cement Mix', '378355', 5, 2, '334', 44, '2024-11-21 10:15:03', '2024-11-21 10:15:03'),
(2, '822da601-4a9d-457b-bcbb-c3378e29f6fe', 'Hammer', '834306', 3, 2, '178', 52, '2024-09-08 10:15:05', '2024-09-08 10:15:05'),
(3, '367ca9e5-3c1b-49c7-9394-de04ac700f8f', 'Safety Helmet', '430755', 2, 3, '124', 84, '2025-01-05 10:15:05', '2025-01-05 10:15:05'),
(4, '3615a4f5-b19a-4a9b-95ee-8cddea1c6587', 'Wiring Cable', '706347', 4, 2, '497', 75, '2024-08-25 10:15:05', '2024-08-25 10:15:05'),
(5, '54555f2e-f49e-4948-8227-d956129bc4d8', 'PVC Pipes', '394606', 2, 4, '296', 70, '2024-03-05 10:15:05', '2024-03-05 10:15:05'),
(6, '1030a8c7-1cfc-4204-90ab-559c52c7ce99', 'Paint (White)', '811232', 3, 4, '153', 0, '2025-01-29 10:15:05', '2025-01-29 10:15:05'),
(7, 'e0a5149b-c739-462e-a501-e0e206e427be', 'Wood Planks (2x4)', '188757', 5, 3, '273', 70, '2024-05-24 10:15:05', '2024-05-24 10:15:05'),
(8, '7d913c04-82a5-4120-a7b0-14864b60a273', 'Drill Machine', '747210', 4, 3, '138', 10, '2024-02-09 10:15:05', '2024-02-09 10:15:05'),
(9, '333f2531-b769-4cc1-89db-8e9f848b2e96', 'Saw Blade', '179717', 1, 5, '405', 62, '2024-03-30 10:15:05', '2024-03-30 10:15:05'),
(10, 'f349ebdb-9db4-40b4-9435-e8abe9bdb2a3', 'Nails (Assorted)', '664886', 2, 2, '317', 59, '2024-06-19 10:15:05', '2024-06-19 10:15:05'),
(11, '66acbdcb-529c-413b-90df-c4297e53990d', 'Screwdriver Set', '876051', 1, 3, '161', 54, '2024-04-30 10:15:05', '2024-04-30 10:15:05'),
(12, 'bf341337-5a86-44e0-a3fb-1fe9fd002c28', 'Plywood Sheets', '333680', 2, 2, '349', 11, '2024-03-21 10:15:05', '2024-03-21 10:15:05'),
(13, '20803bde-4787-406c-9a32-5d791aaf4062', 'Tile Adhesive', '645351', 2, 2, '371', 5, '2024-06-29 10:15:05', '2024-06-29 10:15:05'),
(14, '3a2566c2-077d-427c-bef6-b3b9c763416c', 'Measuring Tape', '876671', 3, 4, '225', 51, '2024-07-23 10:15:05', '2024-07-23 10:15:05'),
(15, 'd0f08c17-7b49-44d1-a4ac-d4ed27ed1a33', 'Concrete Blocks', '862232', 2, 2, '109', 67, '2024-12-09 10:15:05', '2024-12-09 10:15:05'),
(16, '4fbc4ca8-d68e-418f-8e39-edcda46c2e0e', 'Roofing Sheets', '644070', 5, 3, '483', 1, '2024-09-03 10:15:05', '2024-09-03 10:15:05'),
(17, '7090ef7a-409b-4978-b0f7-d358f2abce1b', 'Aluminum Ladders', '364327', 3, 4, '368', 77, '2024-05-15 10:15:05', '2024-05-15 10:15:05'),
(18, 'b47a4028-b31a-4ead-b518-f0a5cc50e024', 'Electrical Tape', '826582', 2, 3, '183', 16, '2024-11-12 10:15:05', '2024-11-12 10:15:05'),
(19, '9a1ec080-88f8-46f5-a216-7072dd510b7c', 'Extension Cord', '644971', 2, 5, '159', 70, '2024-10-12 10:15:05', '2024-10-12 10:15:05'),
(20, '1abc189c-b920-4519-8480-772bb5e5b247', 'Plumbing Fittings', '723617', 4, 2, '322', 65, '2024-03-23 10:15:05', '2024-03-23 10:15:05'),
(21, 'cd926edd-a195-4013-9265-035e54fb6550', 'Angle Grinder', '594608', 4, 4, '132', 11, '2024-04-28 10:15:05', '2024-04-28 10:15:05'),
(22, 'bd43b4a6-218e-44b4-9558-79d8ee4739f7', 'Hacksaw', '748261', 1, 4, '425', 6, '2024-11-26 10:15:05', '2024-11-26 10:15:05'),
(23, '49f1d398-2500-47c7-b51a-b1aa68abb92a', 'Chisels Set', '502320', 5, 2, '391', 65, '2025-01-13 10:15:05', '2025-01-13 10:15:05'),
(24, '45264655-7a4d-46e7-8066-46ab0dd8c674', 'Sandpaper Pack', '854525', 1, 1, '150', 61, '2024-10-19 10:15:05', '2024-10-19 10:15:05'),
(25, 'eddf9b04-67d4-4726-8e0a-095fcdbec0d4', 'Work Gloves', '349597', 2, 3, '258', 33, '2024-06-12 10:15:05', '2024-06-12 10:15:05'),
(26, '9c9d5330-1285-40e7-b925-50e06ef9b7af', 'Safety Goggles', '112838', 2, 1, '381', 71, '2024-05-28 10:15:05', '2024-05-28 10:15:05'),
(27, '68f35b92-7d38-497b-87ae-decac8646d6a', 'Wheelbarrow', '925909', 1, 1, '289', 13, '2024-11-07 10:15:05', '2024-11-07 10:15:05'),
(28, '11ef78a6-074b-4742-b7d5-d0d10fd95264', 'Cement Blocks', '579645', 5, 5, '345', 50, '2024-10-30 10:15:05', '2024-10-30 10:15:05'),
(29, 'f16cf8a3-6265-4ec9-80f4-5e045d2ba5d7', 'Brick Trowel', '984298', 3, 2, '303', 65, '2024-10-20 10:15:05', '2024-10-20 10:15:05'),
(30, '75996d83-c409-4646-a58d-381e539be2be', 'Spirit Level', '236935', 2, 3, '391', 100, '2024-08-19 10:15:05', '2024-08-19 10:15:05');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_date` date NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `invoice_number` varchar(255) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total_amount` decimal(10,2) GENERATED ALWAYS AS (`quantity` * `unit_price` - `discount`) VIRTUAL,
  `grand_total` decimal(10,2) GENERATED ALWAYS AS (`total_amount` + `tax_amount`) VIRTUAL,
  `payment_method` enum('Bank Transfer','Cash','Credit') NOT NULL,
  `purchase_status` enum('Received','Pending','Canceled') NOT NULL,
  `payment_status` enum('Paid','Unpaid','Partially Paid') NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `purchase_date`, `supplier_id`, `invoice_number`, `product_id`, `quantity`, `unit_price`, `discount`, `tax_amount`, `payment_method`, `purchase_status`, `payment_status`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-02-09', 2, '811232', 6, 30, 153.00, 0.00, 0.00, 'Cash', 'Pending', '', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sale_date` date NOT NULL,
  `sales_rep` varchar(255) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_status` enum('Paid','Pending','Partially Paid') NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `sale_date`, `sales_rep`, `customer_name`, `customer_id`, `product_id`, `quantity`, `unit_price`, `total_amount`, `payment_status`, `notes`, `created_at`, `updated_at`) VALUES
(1, '2025-02-09', 'Josh', 'Joshi Angelo', '123456', 2, 7, 178.00, 1246.00, 'Pending', 'Hello World', NULL, NULL),
(2, '2025-02-09', 'Joshi Angelo', 'Joshi Angelo Z. Adlawan', '456789', 3, 4, 124.00, 496.00, 'Paid', 'fHello World again', NULL, NULL),
(3, '2025-02-09', 'haha', 'hahah', '45', 3, 4, 124.00, 496.00, 'Paid', 'Hello World napud', NULL, NULL),
(4, '2025-02-09', 'last', 'last testing', '5468', 3, 4, 124.00, 496.00, 'Paid', 'Hello World last nani', NULL, NULL),
(5, '2025-02-09', 'Joshi Angelo', 'Joshi Angelo Z. Adlawan', '123456', 6, 2, 153.00, 306.00, 'Paid', 'Hello World', NULL, NULL),
(6, '2025-02-09', 'Joshi Angelo', 'Joshi Angelo Z. Adlawan', '123456', 6, 30, 153.00, 4590.00, 'Paid', 'fully paid', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supplier_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `supplier_name`, `created_at`, `updated_at`) VALUES
(1, 'Little, Hills and Schulist', '2025-02-09 10:15:03', '2025-02-09 10:15:03'),
(2, 'Moore and Sons', '2025-02-09 10:15:03', '2025-02-09 10:15:03'),
(3, 'Jakubowski-McCullough', '2025-02-09 10:15:03', '2025-02-09 10:15:03'),
(4, 'Kulas-Hoeger', '2025-02-09 10:15:03', '2025-02-09 10:15:03'),
(5, 'Romaguera-Kunze', '2025-02-09 10:15:03', '2025-02-09 10:15:03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_uuid_unique` (`uuid`),
  ADD KEY `products_supplier_id_foreign` (`supplier_id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchases_supplier_id_foreign` (`supplier_id`),
  ADD KEY `purchases_product_id_foreign` (`product_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_product_id_foreign` (`product_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `products_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `purchases_supplier_id_foreign` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
